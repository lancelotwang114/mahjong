# Mahjong Design System (台灣麻將)

A design system extracted from **mahjong-solo** — a pure front-end Taiwanese 16-tile Mahjong game, single HTML file, no backend, no framework dependencies.

> **Live demo:** https://lancelotwang114.github.io/mahjong/mahjong-solo.html
> **Source repo:** lancelotwang114/mahjong (`main` branch)

---

## Product context

**台灣麻將 單機版 (Taiwan Mahjong — Solo Edition)** is a browser-based, single-file mahjong game that runs entirely client-side. It combines the **classical visual language of a real mahjong table** (felt, wood, gold-edged tiles, ivory faces with red/blue/green pip glyphs) with **modern game-UI polish** (dice rolling animations, particle effects, tile-flight transitions, themeable tabletops, ambient drone-and-pluck background music).

The product is one surface — a fixed **1280×720** game canvas that scales to fit any viewport via `transform: scale()`. Within that canvas, the user moves through three main "screens":

1. **Lobby (大廳)** — settings cards: 底台, 每台金額, 起始籌碼, 出牌限時, 語音, AI 個性, theme picker, sound theme, BGM toggle, stats panel with chart.
2. **Game table (牌桌)** — top opponent (p2/西), left (p3/北), right (p1/南), self at bottom (p0/東). Center pool with compass circle, dice, deck progress bar, score badges. Discards in 4 zones around the compass.
3. **Match summary (結算)** — full-screen overlay listing 4-player rankings, final chips, payouts, and bonuses (台型).

There is also a **multiplayer legacy version** (`index.html` + `js/`) that shares the visual vocabulary.

### Sources

- **Repo:** `github.com/lancelotwang114/mahjong` @ `main`
- **Imported files:** `README.md`, `CLAUDE.md`, `tiles.js`, `game.js`, `preview.png`
- **Main file (not imported, ~580 KB):** `mahjong-solo.html` (HTML+CSS+JS in one document)
- **Sprite assets:** `tiles-sprite.css` + `images/` (萬/筒/條/字/花 PNG sprites — base64 inlined in main file)

---

## Index

```
.
├── README.md                  ← this file
├── SKILL.md                   ← agent skill manifest
├── colors_and_type.css        ← root CSS tokens (colors, type, spacing, radii)
├── fonts/                     ← Google Font CSS link (no local fonts shipped)
├── assets/                    ← logos, brand marks, tile glyphs, motifs
├── preview/                   ← Design System tab cards (registered)
│   ├── colors-felt.html
│   ├── colors-gold.html
│   ├── colors-suits.html
│   ├── type-display.html
│   ├── type-body.html
│   ├── radii-shadows.html
│   ├── tiles-specimen.html
│   ├── badges-buttons.html
│   ├── compass-card.html
│   └── ...
├── ui_kits/
│   └── solo-game/
│       ├── index.html         ← interactive lobby + table prototype
│       ├── README.md
│       └── *.jsx              ← Lobby, Table, Tile, Compass, Badges...
└── preview.png                ← canonical screenshot from upstream
```

---

## Content fundamentals

The product is **bilingual-leaning Mandarin Chinese** (Traditional, `lang="zh-TW"`) with rare English version-tags. Voice is **terse, kinetic, evocative** — the tone of a tabletop game in flight, not a productivity app.

### Voice & tone

- **Direct, imperative, fragmentary.** Buttons are 2–3 characters: 開始, 跳過, 暫停, 不要, 胡！. Headings drop punctuation.
- **No "you" / no "I".** The interface speaks *about* the table state ("小東 補花：蘭" — "South-East draws flower: Lan"), not *to* the user.
- **Game vocabulary is canonical.** 碰 / 吃 / 槓 / 胡 / 自摸 / 聽牌 / 流局 / 海底撈月 / 槓上開花 / 十三么 / 對對胡 / 清一色 — these terms are used as-is, never softened or translated.
- **Numbers are spelled in glyphs for tiles** (一萬, 二筒, 九索) and in arabics for chips/timers ($5,000, 12s).
- **Casing:** N/A — Chinese. English fragments (CHANGELOG headings, version tags) use sentence case in zh-TW context, never SHOUTY CAPS.
- **Emphasis** comes from punctuation — `胡！` (with bang) rather than bold/italics. Bang reserved for win declarations.
- **Logging tone is neutral, third-person, present tense:** `小東 打出 三萬`, `小南 補花：菊  抽替補牌繼續`. Never "You discarded…".

### Emoji usage

Emoji are **part of the brand**, used surgically:

- **🀇 🀐 🀙 🀀 🀄 🀅 🀆** — actual Unicode mahjong tiles, used in titles and version pills only.
- **🌅 🌄** — used to differentiate east-wind (4-round) vs south-wind (8-round) game modes on the lobby cards.
- **🐉 🐯 🦢** — assigned to the three AI opponents (South=Tiger, West=Dragon, North=Crane). Persistent identity, never shuffled.
- **💡** for the hint button. **🎯 💎 🔕** for the three sound themes (classic/modern/mute). **⚙ 🀄 ⚡** for assist toggles.
- **🎉** for win celebrations only.

Emoji never appear inside body copy or as filler — only as compact iconography on dedicated controls.

### Examples

| Surface | Copy |
|---|---|
| Lobby section header | 大廳 / 底台 / 每台金額 / 起始籌碼 |
| Mode card | 🌅 東風局（4 局快打）/ 🌄 南風局（8 局全場） |
| AI personality | 攻擊型 / 均衡型 / 守備型 |
| Action buttons | 碰  吃  槓  胡！  跳過  不要 |
| Game log | 🎉 玩家 胡牌！3台 共付$300 |
| Win bonuses | 底 1台 / 自摸 1台 / 門清 1台 / 七對 3台 |
| Toast | ✓ 配對成功！ |

---

## Visual foundations

### The core feel

A **dim, warm casino game table at night**. Deep felt green dominates 70–80% of every surface. Wood-brown frames hem the play area. Gold (a single warm hue, never silver) carries every accent — borders, scorelights, the compass ring, win glows, hover halos. Ivory-white tile faces sit on the felt with **3px×8px×14px shadows** to feel weighty. Suits use saturated **inks** (red 萬, blue 筒, green 索) that look painted, not vector.

There is **no flat design** anywhere. Everything has depth: gradients, inner shadows, outer glows, pulsing rings, particle drift.

### Color palette

| Role | Token | Value | Notes |
|---|---|---|---|
| Felt primary | `--felt` | `#0a3d2e` (default), `#3a2a1a` wood, `#0f4530` jade, `#1a0f2e` noir | tabletop background |
| Felt accent | `--felt2` | `#0d2a1f` | inner shadow / pool edge |
| Wood frame | `--wood` | `#5c3a1e` | outer table border |
| Gold primary | `--gold` | `#d4a843` | borders, ring lights, winner halos |
| Gold bright | `--gold2` | `#f0c850` | hover/active emphasis, dice highlights |
| Gold dim | `--gold3` | `#8b6f2a` | inactive state of gold |
| Ivory tile face | `--ivory` | `linear-gradient(180deg,#f8f2e0,#e8dcc0)` | tile body |
| Ink red | `--ink-red` | `#c83838` | 萬 series + 中 |
| Ink blue | `--ink-blue` | `#2a4f8a` | 筒 series + 北 |
| Ink green | `--ink-green` | `#2d7d3f` | 索 series + 發 |
| Ink black | `--ink-black` | `#1a1a1a` | 字牌 (東/南/西/北/白) |
| BG dark | `--bg-dark` | `#0a0a0a` | letterbox outside the 1280×720 canvas |
| Text on dark | `--fg1` | `#f4ead0` | primary copy on felt |
| Text muted | `--fg2` | `#c8b888` | secondary / log lines |
| Danger | `--danger` | `#e85a4f` | timer-low, danger-high tile dots |
| Warning | `--warn` | `#f0a830` | timer-mid, danger-mid |
| Success | `--success` | `#5fb878` | tenpai, danger-low |

### Typography

- **Display / brand:** `Ma Shan Zheng` — a brushed Chinese script for `胡！`, win overlays, lobby title, mode cards. Used sparingly, sized 48–96px.
- **Serif (chrome titles, scores):** `Noto Serif TC` weights 700/900 — score badges, compass cardinal labels (東 南 西 北), settings card headers.
- **Sans (UI / body / log):** `Noto Sans TC` weights 400/700 — buttons, log lines, tooltips, settings values.
- **No monospace** — counters and timers use serif tabular figures.

Loaded via Google Fonts:
```
https://fonts.googleapis.com/css2?family=Ma+Shan+Zheng&family=Noto+Serif+TC:wght@700;900&family=Noto+Sans+TC:wght@400;700&display=swap
```

### Spacing, radii, shadows

- **Spacing** is grid-aligned to 4px on the 1280×720 canvas. Common values: `4 / 8 / 12 / 16 / 20 / 32 / 60`.
- **Radii:** tiles 6px, cards 12px, badges & capsules `999px` (full pill), the compass is a perfect circle (200px).
- **Tile shadow** is the signature: `box-shadow: 3px 8px 14px rgba(20,10,0,.55), 0 2px 4px rgba(0,0,0,.30)` — long, warm, low-spread. Applied to every face-up tile.
- **Card shadow:** `0 4px 12px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.08)` — outer depth + inner highlight rim.
- **Gold glow** for winning / candidate tiles: `0 0 10px rgba(212,168,67,.85)` plus a 2.5px gold outline.

### Backgrounds & motifs

- **Felt texture** is built from 4 layered `linear-gradient(45deg/-45deg/...)` cross-hatch passes giving an embroidered cloth feel. Never use a flat color.
- **Lobby background** layers SVG mahjong tile silhouettes (rotated, dimmed to ~6% opacity) and a double radial gradient (warm center → dark edges).
- **Dust particles** — 12 absolutely-positioned dots drift slowly across the table. Color follows theme (gold/brown/green/violet).
- **No photos. No illustrations of people.** All decoration is pattern, glyph, or geometry.

### Animation & motion

- **Easing:** the system favors `cubic-bezier(.16,1,.3,1)` (deceleration) for entries and `ease-in` for exits. Bouncy `cubic-bezier(.34,1.56,.64,1)` for dice landings and tile-fly arrivals.
- **Durations:** UI feedback ~150ms, tile-fly 320ms, dice spin 1.4s, win overlay 600ms, dust drift 28–60s loop.
- **Signature motions:** dice 3D `perspective` rotate + bounce + gold halo + 6 spark particles; discarded-tile flight (clone with `getBoundingClientRect()` → fixed-position transition); winner tile pulsing gold (`@keyframes haloPulse`); the just-discarded tile of each player carries a `.hi-prev` static gold frame, the *very last* discard carries `.hi` (animated pulse).
- **No fade-only.** Every entrance has a subtle scale or translate component.

### Hover, press, focus

- **Hover** raises the element 4–8px (`transform: translateY(-4px) scale(1.02)`) and adds the gold-glow shadow. Buttons brighten one step (gold → gold-bright).
- **Press** drops back to the resting position with a `transform: scale(.97)` and darkens to `--gold3`.
- **Focus** matches hover but adds a 2.5px gold outline (the same outline used for tile candidates), respecting keyboard nav.
- **Disabled** drops to 35% opacity and `cursor: not-allowed`. No greying out — it stays gold but dimmed.

### Borders, blur, transparency

- **Borders are gold-on-felt** (1–2px solid `--gold` at 30–60% opacity for resting, full opacity for active).
- **Capsule pills** for inline tags (player wind tags 東/南/西/北), 999px radius, 1px gold border, transparent fill.
- **Backdrop-filter blur** is used **only on full-screen overlays** (win/match summary): `backdrop-filter: blur(8px)` over `rgba(0,0,0,.55)`.
- **Protection gradients** (top/bottom of the table) — none. The product trusts the felt and uses opaque score badges instead.

### Layout rules

- **Fixed canvas:** 1280×720 wrapped in a viewport-fill stage, `transform: scale()` to fit.
- **Center compass at 640,330** (the visual gravity center, not the geometric).
- **Symmetry:** opponents are mirrored. p1/p3 (left/right) hands rotate `-90°` and `90°`; p2 hand at the top is upright but smaller (ti size).
- **No grid system in the western sense** — positions are absolute and pixel-pinned because the canvas is fixed.

### Imagery vibe

Warm, dim, slightly amber. Black is never pure `#000` on the table — always `#0a0a0a` or `#0d2a1f`. The whole palette is filtered through a "candlelit room" mood.

---

## Iconography

The product **avoids decorative icon libraries entirely**. Its iconographic vocabulary is built from three stocks:

1. **Custom SVG tile glyphs** — the core asset. `tileSVG(tile)` generates per-tile SVG (rendered behind the PNG sprite as a fallback / overlay). For every face-up tile, a CSS sprite background also loads from a base64-inlined PNG sheet (`tiles-sprite.css`) covering 萬/筒/條/字/花 in 4 sizes (62×86, 32×44, 22×30, 28×39). The pip layouts (one-suit, dot-suit, bamboo-suit) and honor characters are drawn faithfully to physical tile aesthetics.
2. **Unicode CJK glyphs** as iconography: 東 南 西 北 中 白 發, 春 夏 秋 冬 梅 蘭 菊 竹 — these double as both content and "icons" on score badges, compass labels, and flower indicators.
3. **Emoji** for compact button affordances (see Content Fundamentals): 🀄 ⚙ ⚡ 💡 🎯 💎 🔕 🌅 🌄 🐉 🐯 🦢 🎉. These are **system emoji** — rendered with whatever the OS provides. No emoji font is shipped.

There is **no icon font** (no Lucide, no Heroicons, no FontAwesome). There are **no PNG icons** other than the tile sprites. There are **no decorative line-icons** (no info-circles, gear-cogs in SVG, etc.) — every "icon" is either a tile, a CJK glyph, or a system emoji.

This is a deliberate constraint: the product reads as a *real mahjong table* rather than a generic web app, and the limited iconographic stock reinforces that.

### Substitutions in this design system

When recreating views in HTML and an icon is genuinely missing (e.g. a close button, a hamburger), prefer:
1. A CJK glyph (×, ☰, ⚙) before reaching for emoji.
2. The tile sprite sheet (assets/) for any tile reference.
3. **Never** invent new SVG icons — the product would not.

---

## Caveats & substitutions

- **Fonts** are loaded from Google Fonts. No `.ttf`/`.woff2` files are shipped in this design system. If you need offline use, download `Ma Shan Zheng`, `Noto Serif TC`, and `Noto Sans TC` from fonts.google.com.
- **Tile sprite PNGs** were not extracted from the upstream (they are base64-inlined in the 580KB main HTML). The UI kit re-creates tiles via Unicode mahjong characters (🀇–🀫) plus CJK glyph fallbacks for honors/flowers. **Flag for upstream:** copy the `images/` folder from the repo if pixel-perfect tile sprites are required.
- **Sound design** (Web Audio drones, plucks, white noise) is not part of this visual design system but is documented in CLAUDE.md should it ever need recreating.
- **Accessibility** — the source design has very low contrast (gold-on-felt) at small sizes and uses color (red/yellow/green danger dots) without secondary cues. This is preserved as-is for fidelity but flagged for any production work.
