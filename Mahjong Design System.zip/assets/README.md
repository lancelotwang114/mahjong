# Assets

Source assets and reference materials extracted from the upstream repo.

| File | Purpose |
|---|---|
| `screenshot-table.png` | Canonical screenshot of the game table (1280×720). Single source of truth for the visual reference. |
| `tiles-engine.js` | Tile vocabulary, deck construction, win-detection logic (read-only reference). |
| `game-state.js` | Game state shape (read-only reference). |

## Tile glyphs (Unicode)

The product uses a custom PNG sprite for tile faces, but the entire tile vocabulary is also expressible as Unicode CJK + mahjong-block characters. The UI kit (`ui_kits/solo-game/`) renders tiles using these characters so no binary sprite shipping is needed:

- 萬 series: `🀇 🀈 🀉 🀊 🀋 🀌 🀍 🀎 🀏`
- 筒 series: `🀙 🀚 🀛 🀜 🀝 🀞 🀟 🀠 🀡`
- 索 series: `🀐 🀑 🀒 🀓 🀔 🀕 🀖 🀗 🀘`
- 字牌: `🀀 🀁 🀂 🀃 🀄 🀅 🀆` (East South West North Red White Green)
- 花牌: `🀢 🀣 🀤 🀥 🀦 🀧 🀨 🀩` (Plum Orchid Chrysanthemum Bamboo / Spring Summer Autumn Winter)
- Tile back: `🀫`

For pixel-perfect production work, copy the upstream `images/` folder and `tiles-sprite.css` from `lancelotwang114/mahjong`.
