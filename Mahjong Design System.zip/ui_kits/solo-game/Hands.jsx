// Hands.jsx — player hand zones for all 4 positions
function PlayerHand({ tiles, position, onDiscard, drawnId, candidates }) {
  if (position === 'bottom') {
    return (
      <div className="hand-bottom">
        {tiles.map((t, i) => (
          <Tile
            key={t.id}
            tile={t}
            size="full"
            onClick={onDiscard ? () => onDiscard(t) : null}
            candidate={candidates && candidates.includes(t.id)}
            className={t.id === drawnId ? 'drawn' : ''}
          />
        ))}
      </div>
    );
  }
  if (position === 'top') {
    return (
      <div className="hand-top">
        {tiles.map((_, i) => <Tile key={i} back size="ti" />)}
      </div>
    );
  }
  if (position === 'left') {
    return (
      <div className="hand-left">
        {tiles.map((_, i) => <Tile key={i} back size="sm" />)}
      </div>
    );
  }
  if (position === 'right') {
    return (
      <div className="hand-right">
        {tiles.map((_, i) => <Tile key={i} back size="sm" />)}
      </div>
    );
  }
  return null;
}

function DiscardZone({ tiles, position, lastIdx, lastPrevIdx }) {
  return (
    <div className={`discard ${position}`}>
      {tiles.map((t, i) => (
        <Tile
          key={t.id}
          tile={t}
          size="ti"
          hi={i === lastIdx}
          hiPrev={i === lastPrevIdx}
        />
      ))}
    </div>
  );
}

window.PlayerHand = PlayerHand;
window.DiscardZone = DiscardZone;
