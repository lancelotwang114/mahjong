// Tile.jsx — face / back / candidate tile renderer
const TILE_GLYPHS = {
  man: ['一','二','三','四','五','六','七','八','九'],
  pin: ['一','二','三','四','五','六','七','八','九'],
  sou: ['一','二','三','四','五','六','七','八','九'],
  honor: ['東','南','西','北','中','白','發'],
  flower: ['梅','蘭','菊','竹','春','夏','秋','冬'],
};

function suitClass(suit, value) {
  if (suit === 'honor') {
    if (value === 4) return 'hon-r';   // 中
    if (value === 6) return 'hon-g';   // 發
    return '';
  }
  if (suit === 'flower') {
    return value < 4 ? 'flower-r' : 'flower-g';
  }
  return suit;
}

function Tile({ tile, size = 'sm', className = '', onClick, candidate, hi, hiPrev, dim, back }) {
  const sz = size; // 'full' | 'sm' | 'ti'
  if (back) {
    return (
      <div className={`tile back ${sz} ${className}`}>
        🀫
      </div>
    );
  }
  const glyph = TILE_GLYPHS[tile.suit][tile.value - (tile.suit === 'honor' || tile.suit === 'flower' ? 0 : 1)];
  const cls = [
    'tile', sz, suitClass(tile.suit, tile.value),
    candidate ? 'candidate' : '',
    hi ? 'hi' : '',
    hiPrev ? 'hi-prev' : '',
    dim ? 'dim' : '',
    onClick ? 'clickable' : '',
    className,
  ].filter(Boolean).join(' ');
  return (
    <div className={cls} onClick={onClick}>{glyph}</div>
  );
}

window.Tile = Tile;
window.TILE_GLYPHS = TILE_GLYPHS;
