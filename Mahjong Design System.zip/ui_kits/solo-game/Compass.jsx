// Compass.jsx — center pool with round wind + deck progress
function Compass({ roundWind = '東', round = 1, deckLeft = 47, deckTotal = 76, activeWind = '東' }) {
  const winds = ['東', '南', '西', '北'];
  const positions = {
    '東': { right: 8, top: '50%', transform: 'translateY(-50%)' },
    '南': { bottom: 8, left: '50%', transform: 'translateX(-50%)' },
    '西': { left: 8, top: '50%', transform: 'translateY(-50%)' },
    '北': { top: 8, left: '50%', transform: 'translateX(-50%)' },
  };
  const pct = Math.round(deckLeft / deckTotal * 100);
  return (
    <div className="compass">
      {winds.map(w => (
        <div
          key={w}
          className={`compass-cardinal ${w === activeWind ? 'active' : ''}`}
          style={positions[w]}
        >{w}</div>
      ))}
      <div className="compass-text">{roundWind}風</div>
      <div className="compass-sub">第 {round} 局</div>
      <div className="compass-bar"><div style={{width: pct + '%'}}></div></div>
      <div className="compass-sub" style={{fontSize:9, marginTop:2}}>{deckLeft} / {deckTotal}</div>
    </div>
  );
}
window.Compass = Compass;
