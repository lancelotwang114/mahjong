// ScoreBadge.jsx + ActionOverlay.jsx + WindTag.jsx
function ScoreBadge({ wind, name, money, active, position }) {
  return (
    <div className={`score-badge ${active ? '' : 'dim'}`} style={position}>
      <div className="wind">{wind}</div>
      <div className="name">{name}</div>
      <div className="money">${money.toLocaleString()}</div>
    </div>
  );
}

function ActionOverlay({ canHu, canPong, canChi, canKong, onAction, onSkip }) {
  if (!canHu && !canPong && !canChi && !canKong) return null;
  return (
    <div className="actions">
      {canHu && <button className="btn primary" onClick={() => onAction('hu')}>胡！</button>}
      {canPong && <button className="btn" onClick={() => onAction('pong')}>碰</button>}
      {canChi && <button className="btn" onClick={() => onAction('chi')}>吃</button>}
      {canKong && <button className="btn" onClick={() => onAction('kong')}>槓</button>}
      <button className="btn ghost" onClick={onSkip}>跳過</button>
    </div>
  );
}

function WindTag({ wind, name, isDealer, isPlayer }) {
  return (
    <div className="wind-tag">
      <span className="red">{wind}</span>
      {isDealer && <><span>·</span><span>莊</span></>}
      <span>·</span>
      <span style={{color: isPlayer ? 'var(--gold2)' : 'var(--fg2)'}}>{name}</span>
    </div>
  );
}

window.ScoreBadge = ScoreBadge;
window.ActionOverlay = ActionOverlay;
window.WindTag = WindTag;
