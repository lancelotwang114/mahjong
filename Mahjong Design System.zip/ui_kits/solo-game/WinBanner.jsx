// WinBanner.jsx — end-of-hand 胡！overlay
function WinBanner({ winner, taiList = [], total, payouts, onContinue }) {
  return (
    <div className="win-overlay">
      <div className="han">胡！</div>
      <div style={{fontFamily:'var(--font-serif)', fontWeight:700, fontSize:22, color:'var(--fg1)'}}>
        {winner} · 共 {total} 台
      </div>
      <div className="tai-row">
        {taiList.map((t, i) => <div key={i} className="tai-pill">{t.name} {t.value}台</div>)}
      </div>
      <div style={{fontFamily:'var(--font-sans)', fontSize:14, color:'var(--fg2)', marginTop:8}}>
        {payouts}
      </div>
      <button className="btn primary" style={{marginTop:18}} onClick={onContinue}>下一局</button>
    </div>
  );
}
window.WinBanner = WinBanner;
