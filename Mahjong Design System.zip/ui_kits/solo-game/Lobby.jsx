// Lobby.jsx — pre-game settings card grid
function Lobby({ onStart }) {
  const [base, setBase] = React.useState(1);
  const [tai, setTai] = React.useState(100);
  const [money, setMoney] = React.useState(10000);
  const [mode, setMode] = React.useState('east');
  const [aiStyles, setAiStyles] = React.useState(['balanced','attack','defense']);
  const [theme, setTheme] = React.useState('default');
  const [snd, setSnd] = React.useState('modern');

  React.useEffect(() => {
    document.documentElement.dataset.theme = theme === 'default' ? '' : theme;
  }, [theme]);

  const setAi = (i, v) => setAiStyles(s => s.map((x, j) => j === i ? v : x));

  const Seg = ({ value, options, onChange }) => (
    <div className="seg">
      {options.map(o => (
        <button key={o.v} className={value === o.v ? 'active' : ''} onClick={() => onChange(o.v)}>
          {o.label}
        </button>
      ))}
    </div>
  );

  return (
    <div className="lobby">
      <div style={{textAlign:'center'}}>
        <h1>台灣麻將</h1>
        <div className="sub">SOLO · 16 TILES · v1.5.3</div>
      </div>
      <div className="settings-grid">
        <div className="settings-card">
          <div className="lbl">底台</div>
          <Seg value={base} onChange={setBase} options={[{v:1,label:'1台'},{v:3,label:'3台'},{v:5,label:'5台'}]} />
        </div>
        <div className="settings-card">
          <div className="lbl">每台金額</div>
          <Seg value={tai} onChange={setTai} options={[{v:50,label:'$50'},{v:100,label:'$100'},{v:200,label:'$200'}]} />
        </div>
        <div className="settings-card">
          <div className="lbl">起始籌碼</div>
          <Seg value={money} onChange={setMoney} options={[{v:5000,label:'5K'},{v:10000,label:'10K'},{v:20000,label:'20K'}]} />
        </div>
        <div className="settings-card">
          <div className="lbl">局制</div>
          <Seg value={mode} onChange={setMode} options={[{v:'east',label:'🌅 東風 (4)'},{v:'south',label:'🌄 南風 (8)'}]} />
        </div>
        <div className="settings-card">
          <div className="lbl">音效主題</div>
          <Seg value={snd} onChange={setSnd} options={[{v:'classic',label:'🎯 古典'},{v:'modern',label:'💎 現代'},{v:'mute',label:'🔕 靜音'}]} />
        </div>
        <div className="settings-card">
          <div className="lbl">桌布</div>
          <Seg value={theme} onChange={setTheme} options={[{v:'default',label:'翠竹'},{v:'wood',label:'紅木'},{v:'jade',label:'翡翠'},{v:'noir',label:'夜墨'}]} />
        </div>
        <div className="settings-card">
          <div className="lbl">小東 個性 🐯</div>
          <Seg value={aiStyles[0]} onChange={(v) => setAi(0,v)} options={[{v:'attack',label:'攻擊'},{v:'balanced',label:'均衡'},{v:'defense',label:'守備'}]} />
        </div>
        <div className="settings-card">
          <div className="lbl">小西 個性 🐉</div>
          <Seg value={aiStyles[1]} onChange={(v) => setAi(1,v)} options={[{v:'attack',label:'攻擊'},{v:'balanced',label:'均衡'},{v:'defense',label:'守備'}]} />
        </div>
        <div className="settings-card">
          <div className="lbl">小北 個性 🦢</div>
          <Seg value={aiStyles[2]} onChange={(v) => setAi(2,v)} options={[{v:'attack',label:'攻擊'},{v:'balanced',label:'均衡'},{v:'defense',label:'守備'}]} />
        </div>
      </div>
      <button className="btn primary" style={{fontSize:22, padding:'12px 60px'}} onClick={onStart}>開始 · 擲骰</button>
    </div>
  );
}

window.Lobby = Lobby;
