// app.jsx — root state machine + Table view
const { useState, useEffect, useRef } = React;

function makeDemoTiles() {
  // A demo hand for visual fidelity
  return [
    {id:1,suit:'man',value:1},{id:2,suit:'man',value:3},{id:3,suit:'man',value:5},
    {id:4,suit:'pin',value:2},{id:5,suit:'pin',value:5},{id:6,suit:'pin',value:8},
    {id:7,suit:'sou',value:3},{id:8,suit:'sou',value:6},{id:9,suit:'sou',value:6},
    {id:10,suit:'sou',value:7},{id:11,suit:'honor',value:0},{id:12,suit:'honor',value:0},
    {id:13,suit:'honor',value:4},{id:14,suit:'honor',value:6},{id:15,suit:'honor',value:6},
    {id:16,suit:'pin',value:9},{id:17,suit:'man',value:7},
  ];
}

function makeDiscards(suit, vals) {
  return vals.map((v, i) => ({id: 1000 + i + Math.random(), suit, value: v}));
}

function Dust() {
  const dots = Array.from({length: 12});
  return <>
    {dots.map((_, i) => (
      <div key={i} className="dust" style={{
        left: (Math.random() * 100) + '%',
        top: (Math.random() * 100) + '%',
        animationDelay: -Math.random() * 32 + 's',
        animationDuration: (24 + Math.random() * 24) + 's',
      }} />
    ))}
  </>;
}

function Table({ onWin, onExit }) {
  const [hand, setHand] = useState(makeDemoTiles());
  const [discards, setDiscards] = useState({
    bottom: makeDiscards('man', [2,4,6,8,1]).concat(makeDiscards('pin', [3,7])),
    top: makeDiscards('sou', [1,2,4]).concat(makeDiscards('pin', [4,6,9])),
    left: makeDiscards('man', [9,8,2]),
    right: makeDiscards('honor', [1,2,3]).concat(makeDiscards('sou', [9])),
  });
  const [turn, setTurn] = useState(0);
  const [log, setLog] = useState('小東 補花：蘭  抽替補牌繼續');

  // Simulated AI cycle
  useEffect(() => {
    if (turn === 0) return; // human turn waits for click
    const t = setTimeout(() => {
      const names = ['', '小東', '小西', '小北'];
      const winds = ['', '南', '西', '北'];
      const suits = ['man','pin','sou'];
      const newTile = {id: Date.now() + Math.random(), suit: suits[Math.floor(Math.random()*3)], value: 1+Math.floor(Math.random()*9)};
      const pos = ['', 'right', 'top', 'left'][turn];
      setDiscards(d => ({ ...d, [pos]: [...d[pos], newTile] }));
      setLog(`${names[turn]} 打出 ${['一','二','三','四','五','六','七','八','九'][newTile.value-1]}${{man:'萬',pin:'筒',sou:'索'}[newTile.suit]}`);
      setTurn((turn + 1) % 4);
    }, 1300);
    return () => clearTimeout(t);
  }, [turn]);

  const onDiscard = (tile) => {
    if (turn !== 0) return;
    setHand(h => h.filter(t => t.id !== tile.id));
    setDiscards(d => ({ ...d, bottom: [...d.bottom, tile] }));
    setLog(`玩家 打出 ${({man:'萬',pin:'筒',sou:'索',honor:'',flower:''})[tile.suit] ? ['一','二','三','四','五','六','七','八','九'][tile.value-1] + ({man:'萬',pin:'筒',sou:'索'})[tile.suit] : tile.suit}`);
    setTurn(1);
  };

  const lastIdx = (arr) => arr.length - 1;
  const lastPrevIdx = (arr) => arr.length - 2;

  return (
    <>
      <button className="pause-btn" onClick={onExit}>⏸ 暫停</button>

      {/* Score badges around the pool */}
      <ScoreBadge wind="北" name="小北 🦢" money={9800} active={turn === 3}
        position={{top: '50%', left: 'calc(50% - 280px)', transform: 'translate(-50%,-50%)'}} />
      <ScoreBadge wind="東" name="玩家" money={10300} active={turn === 0}
        position={{top: '50%', right: 'calc(50% - 280px)', transform: 'translate(50%,-50%)'}} />
      <ScoreBadge wind="北" name="小東 🐯" money={9700} active={turn === 1} 
        position={{display:'none'}} />
      {/* place top + bottom badges */}
      <ScoreBadge wind="西" name="小西 🐉" money={10200} active={turn === 2}
        position={{top: 'calc(50% - 150px)', left: '50%', transform: 'translate(-50%,-50%)'}} />
      <ScoreBadge wind="南" name="小東 🐯" money={9700} active={turn === 1}
        position={{bottom: 'calc(50% - 150px - 30px)', left: '50%', transform: 'translate(-50%,50%)'}} />

      <Compass roundWind="東" round={1} deckLeft={47 - turn} deckTotal={76} activeWind={['東','南','西','北'][turn]} />

      <div className="log-strip">{log}</div>

      {/* Discards */}
      <DiscardZone tiles={discards.bottom} position="bottom" lastIdx={lastIdx(discards.bottom)} lastPrevIdx={lastPrevIdx(discards.bottom)} />
      <DiscardZone tiles={discards.top} position="top" lastIdx={lastIdx(discards.top)} lastPrevIdx={lastPrevIdx(discards.top)} />
      <DiscardZone tiles={discards.left} position="left" lastIdx={lastIdx(discards.left)} lastPrevIdx={lastPrevIdx(discards.left)} />
      <DiscardZone tiles={discards.right} position="right" lastIdx={lastIdx(discards.right)} lastPrevIdx={lastPrevIdx(discards.right)} />

      {/* Opponents */}
      <PlayerHand tiles={Array(16).fill(0).map((_,i)=>({id:i}))} position="top" />
      <PlayerHand tiles={Array(16).fill(0).map((_,i)=>({id:i+100}))} position="left" />
      <PlayerHand tiles={Array(16).fill(0).map((_,i)=>({id:i+200}))} position="right" />

      {/* Player hand */}
      <PlayerHand tiles={hand} position="bottom" onDiscard={turn === 0 ? onDiscard : null} drawnId={hand[hand.length-1]?.id} />
      <WindTag wind="東" name="玩家" isDealer isPlayer />

      {/* Demo: trigger win */}
      <button className="btn primary" style={{position:'absolute', top:14, right:14, fontSize:13, padding:'4px 12px'}} onClick={onWin}>
        模擬胡牌
      </button>
    </>
  );
}

function App() {
  const [screen, setScreen] = useState('lobby');

  // Stage scaling
  const stageRef = useRef(null);
  useEffect(() => {
    const fit = () => {
      const el = stageRef.current;
      if (!el) return;
      const sx = window.innerWidth / 1280;
      const sy = window.innerHeight / 720;
      const s = Math.min(sx, sy, 1);
      el.style.transform = `scale(${s})`;
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);

  return (
    <div className="stage">
      <div className="tbl" ref={stageRef} data-screen-label={screen === 'lobby' ? '01 Lobby' : screen === 'win' ? '03 Win' : '02 Table'}>
        <Dust />
        {screen === 'lobby' && <Lobby onStart={() => setScreen('table')} />}
        {screen === 'table' && <Table onWin={() => setScreen('win')} onExit={() => setScreen('lobby')} />}
        {screen === 'win' && (
          <>
            <Table onWin={() => {}} onExit={() => {}} />
            <WinBanner
              winner="玩家 · 自摸"
              taiList={[
                {name:'底', value:1},
                {name:'自摸', value:1},
                {name:'門清', value:1},
                {name:'莊家', value:1},
              ]}
              total={4}
              payouts="三家共付 $400"
              onContinue={() => setScreen('lobby')}
            />
          </>
        )}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
