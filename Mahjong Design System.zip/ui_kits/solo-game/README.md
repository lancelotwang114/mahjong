# Solo Game UI Kit

An interactive HTML+JSX recreation of the **mahjong-solo** game surface. Components are modular, cosmetic-first (no real game engine), and pixel-faithful to the upstream visuals.

## Files

- `index.html` — interactive prototype: lobby → table → win flow
- `Tile.jsx` — face-up / face-down / candidate tile renderer
- `Compass.jsx` — center pool with round + wind + deck progress
- `ScoreBadge.jsx` — 4-player chip display (N/E/S/W)
- `ActionOverlay.jsx` — 胡/碰/吃/槓/跳過 button cluster
- `PlayerHand.jsx` — bottom hand (own) + side/top hands (opponents)
- `Lobby.jsx` — settings cards + start button
- `WinBanner.jsx` — full-screen 胡！overlay with 台 breakdown
- `app.jsx` — root state machine (lobby → table → win)

## How to extend

Components are JSX files loaded as Babel scripts. Each writes its component(s) to `window` so subsequent files can import them — same pattern as the upstream codebase. Edit any single component file and the prototype reloads instantly.
