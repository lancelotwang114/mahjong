// === DICE — 擲骰動畫 (4 variations) ===

// Each variation is a self-contained dice component with replay button.
// All use real CSS 3D perspective with cube faces, but differ in motion style.

// Helper: render a single 3D cube die with 6 pip faces
const Die3D = React.forwardRef(({ size = 60, value = 1, rotation }, ref) => {
  const half = size / 2;
  const faces = [
    { tx: 'translateZ(' + half + 'px)',                  pips: 1 },
    { tx: 'rotateY(180deg) translateZ(' + half + 'px)',  pips: 6 },
    { tx: 'rotateY(90deg) translateZ(' + half + 'px)',   pips: 4 },
    { tx: 'rotateY(-90deg) translateZ(' + half + 'px)',  pips: 3 },
    { tx: 'rotateX(90deg) translateZ(' + half + 'px)',   pips: 2 },
    { tx: 'rotateX(-90deg) translateZ(' + half + 'px)',  pips: 5 }
  ];
  // map value to which face needs to point at camera
  // value=1 → no extra rotation; we pick rotation externally to land on `value`
  return (
    <div ref={ref} style={{
      width: size, height: size,
      position: 'relative',
      transformStyle: 'preserve-3d',
      transform: rotation
    }}>
      {faces.map((f, i) => (
        <div key={i} style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(135deg, #fafafa, #d6d2c4)',
          borderRadius: size * 0.18,
          boxShadow: 'inset 0 0 0 1px rgba(0,0,0,.2), inset -3px -4px 8px rgba(0,0,0,.18)',
          transform: f.tx,
          backfaceVisibility: 'hidden',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr 1fr',
          gridTemplateRows: '1fr 1fr 1fr',
          padding: size * 0.12, gap: 0,
          alignItems: 'center', justifyItems: 'center'
        }}>
          {pipPositions(f.pips).map((on, idx) => (
            <span key={idx} style={{
              width: size * 0.14, height: size * 0.14,
              borderRadius: '50%',
              background: on ? 'radial-gradient(circle at 30% 30%, #c83838, #6b1818)' : 'transparent',
              boxShadow: on ? 'inset 0 0 2px rgba(0,0,0,.6)' : 'none'
            }}></span>
          ))}
        </div>
      ))}
    </div>
  );
});

function pipPositions(n) {
  // 9-cell grid, true=show pip
  const m = {
    1: [0,0,0, 0,1,0, 0,0,0],
    2: [1,0,0, 0,0,0, 0,0,1],
    3: [1,0,0, 0,1,0, 0,0,1],
    4: [1,0,1, 0,0,0, 1,0,1],
    5: [1,0,1, 0,1,0, 1,0,1],
    6: [1,0,1, 1,0,1, 1,0,1]
  };
  return m[n].map(v=>!!v);
}

// === VARIATION A — Classic spin (current style, polished) ===
function VariantClassic({ playKey }) {
  const [rot, setRot] = React.useState('rotateX(0deg) rotateY(0deg)');
  const [val1, setVal1] = React.useState(3);
  const [val2, setVal2] = React.useState(5);
  const [done, setDone] = React.useState(false);

  React.useEffect(() => {
    setDone(false);
    setRot('rotateX(0deg) rotateY(0deg)');
    requestAnimationFrame(() => {
      const v1 = 1 + Math.floor(Math.random() * 6);
      const v2 = 1 + Math.floor(Math.random() * 6);
      setVal1(v1); setVal2(v2);
      const rx = 720 + Math.floor(Math.random()*360);
      const ry = 720 + Math.floor(Math.random()*360);
      requestAnimationFrame(() => {
        setRot(`rotateX(${rx}deg) rotateY(${ry}deg)`);
      });
    });
    const t = setTimeout(()=>setDone(true), 1400);
    return () => clearTimeout(t);
  }, [playKey]);

  return (
    <div style={{display:'flex', gap:30, justifyContent:'center', alignItems:'center', height:160, perspective:'600px'}}>
      {[val1, val2].map((v,i)=>(
        <div key={i} style={{
          transform: rot,
          transformStyle:'preserve-3d',
          transition: 'transform 1.4s cubic-bezier(.16,1,.3,1)',
          filter: done ? 'drop-shadow(0 0 12px rgba(212,168,67,.7))' : 'drop-shadow(0 6px 8px rgba(0,0,0,.5))'
        }}>
          <Die3D size={60} value={v} rotation="" />
        </div>
      ))}
    </div>
  );
}

// === VARIATION B — Tumble + bounce + shadow ===
function VariantTumble({ playKey }) {
  const [phase, setPhase] = React.useState('idle');
  React.useEffect(() => {
    setPhase('flying');
    const t1 = setTimeout(()=>setPhase('landed'), 1100);
    const t2 = setTimeout(()=>setPhase('settled'), 1500);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [playKey]);

  const flying = phase === 'flying';
  const landed = phase !== 'idle' && phase !== 'flying';

  return (
    <div style={{position:'relative', height:180, perspective:'800px'}}>
      {/* table shadow */}
      <div style={{
        position:'absolute', left:'50%', bottom:30,
        transform:'translateX(-50%)',
        width: 200, height: 16,
        background:'radial-gradient(ellipse, rgba(0,0,0,.6), transparent 70%)',
        filter:'blur(3px)'
      }}></div>
      <div style={{
        display:'flex', gap:36, justifyContent:'center', alignItems:'flex-end',
        height:'100%', paddingBottom: 30
      }}>
        {[0,1].map(i => (
          <div key={i} style={{
            transformStyle:'preserve-3d',
            transform: flying
              ? `translateY(-60px) rotateX(${720 + i*180}deg) rotateY(${540 + i*120}deg) rotateZ(${i*30}deg)`
              : phase === 'landed'
                ? `translateY(-8px) rotateX(${i===0?0:90}deg) rotateY(${i===0?-15:25}deg)`
                : `translateY(0) rotateX(${i===0?0:90}deg) rotateY(${i===0?-15:25}deg)`,
            transition: flying
              ? 'transform 1.1s cubic-bezier(.5,.0,.75,1)'
              : 'transform .4s cubic-bezier(.34,1.56,.64,1)',
            filter: phase === 'settled' ? 'drop-shadow(0 0 14px rgba(240,200,80,.85))' : 'drop-shadow(0 8px 10px rgba(0,0,0,.6))'
          }}>
            <Die3D size={64} rotation="" />
          </div>
        ))}
      </div>
    </div>
  );
}

// === VARIATION C — Toss with arc (real throw) ===
function VariantToss({ playKey }) {
  const [phase, setPhase] = React.useState('idle');
  React.useEffect(() => {
    setPhase('toss');
    const t1 = setTimeout(()=>setPhase('peak'), 500);
    const t2 = setTimeout(()=>setPhase('roll'), 950);
    const t3 = setTimeout(()=>setPhase('settle'), 1700);
    return () => { [t1,t2,t3].forEach(clearTimeout); };
  }, [playKey]);

  const positions = {
    idle:   [{x:-180,y:120,rx:0,ry:0,r:0},   {x:180,y:120,rx:0,ry:0,r:0}],
    toss:   [{x:-90,y:-80,rx:540,ry:360,r:60}, {x:80,y:-100,rx:480,ry:540,r:-90}],
    peak:   [{x:-50,y:-60,rx:900,ry:720,r:120}, {x:30,y:-80,rx:840,ry:900,r:-150}],
    roll:   [{x:-30,y:30,rx:1260,ry:1080,r:200},  {x:50,y:30,rx:1200,ry:1320,r:-260}],
    settle: [{x:-30,y:30,rx:1260,ry:1080,r:200},  {x:50,y:30,rx:1200,ry:1320,r:-260}],
  };
  const dur = phase === 'toss' ? 500
    : phase === 'peak' ? 450
    : phase === 'roll' ? 750
    : phase === 'settle' ? 0
    : 0;

  return (
    <div style={{position:'relative', height:200, perspective:'700px', overflow:'hidden'}}>
      {/* pool surface */}
      <div style={{
        position:'absolute', left:'50%', bottom:18,
        transform:'translateX(-50%)',
        width:280, height:120,
        borderRadius:'50%',
        background:'radial-gradient(ellipse, rgba(0,0,0,.45), transparent 70%)',
        border:'1px solid rgba(212,168,67,.2)',
      }}></div>

      {[0,1].map(i => {
        const p = positions[phase][i];
        return (
          <div key={i} style={{
            position:'absolute',
            left:'50%', top:'50%',
            transformStyle:'preserve-3d',
            transform: `translate(-50%,-50%) translate(${p.x}px, ${p.y}px) rotateZ(${p.r}deg) rotateX(${p.rx}deg) rotateY(${p.ry}deg)`,
            transition: `transform ${dur}ms cubic-bezier(${phase==='roll'?'.5,.0,.6,1':'.34,1.56,.64,1'})`,
            filter: phase==='settle' ? 'drop-shadow(0 0 16px rgba(240,200,80,.9))' : 'drop-shadow(0 8px 12px rgba(0,0,0,.6))'
          }}>
            <Die3D size={56} rotation="" />
          </div>
        );
      })}
    </div>
  );
}

// === VARIATION D — Realistic shake bowl + drop ===
function VariantBowl({ playKey }) {
  const [phase, setPhase] = React.useState('idle');
  React.useEffect(() => {
    setPhase('shake');
    const t1 = setTimeout(()=>setPhase('drop'), 800);
    const t2 = setTimeout(()=>setPhase('bounce'), 1200);
    const t3 = setTimeout(()=>setPhase('settle'), 1600);
    return () => { [t1,t2,t3].forEach(clearTimeout); };
  }, [playKey]);

  const isShake = phase === 'shake';
  const isDrop = phase === 'drop';
  const isBounce = phase === 'bounce';

  return (
    <div style={{position:'relative', height:200, perspective:'800px'}}>
      {/* bowl */}
      <div style={{
        position:'absolute', left:'50%', bottom:20,
        transform:'translateX(-50%)',
        width:200, height:80,
        borderRadius:'50% / 100% 100% 0 0',
        background: 'radial-gradient(ellipse at 50% 30%, #2a1810 0%, #1a0e08 60%, #0a0604 100%)',
        border: '2px solid #5c3a1e',
        borderBottom: '4px solid #3a2410',
        boxShadow: 'inset 0 8px 16px rgba(0,0,0,.6), 0 6px 14px rgba(0,0,0,.5)'
      }}></div>
      {/* dice */}
      <div style={{
        position:'absolute', left:'50%', top:'50%',
        transform:'translate(-50%,-50%)',
        display:'flex', gap:14,
        animation: isShake ? 'bowlShake .12s ease-in-out infinite' : 'none',
        transition: 'transform .35s cubic-bezier(.34,1.56,.64,1)',
        ...(isDrop && {transform:'translate(-50%, -10%)'}),
        ...(isBounce && {transform:'translate(-50%, 20%) scale(.96)'}),
        ...(phase === 'settle' && {transform:'translate(-50%, 18%) scale(1)', filter:'drop-shadow(0 0 14px rgba(240,200,80,.85))'})
      }}>
        {[0,1].map(i => (
          <div key={i} style={{
            transformStyle:'preserve-3d',
            transform: isShake
              ? `rotateX(${(Date.now()/30 + i*60)%360}deg) rotateY(${(Date.now()/40)%360}deg)`
              : `rotateX(${i===0?20:340}deg) rotateY(${i===0?-30:25}deg)`,
            transition: isShake ? 'none' : 'transform .5s cubic-bezier(.34,1.56,.64,1)',
            animation: isShake ? 'cubeSpin .25s linear infinite' : 'none',
          }}>
            <Die3D size={44} rotation="" />
          </div>
        ))}
      </div>
      <style>{`
        @keyframes bowlShake {
          0%,100% { transform: translate(-50%,-50%) translateX(-3px); }
          50%     { transform: translate(-50%,-50%) translateX(3px); }
        }
        @keyframes cubeSpin {
          0%   { transform: rotateX(0) rotateY(0); }
          100% { transform: rotateX(360deg) rotateY(360deg); }
        }
      `}</style>
    </div>
  );
}

const DiceArtboard = () => {
  const [keys, setKeys] = React.useState({ a:0, b:0, c:0, d:0 });

  const Section = ({title, desc, k, Variant}) => (
    <div style={{
      background: 'rgba(0,0,0,.22)',
      border: '1px solid rgba(212,168,67,.18)',
      borderRadius: 8, padding: 16,
      display:'flex', flexDirection:'column'
    }}>
      <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:10}}>
        <h4 style={{margin:0, fontFamily:'var(--font-serif)', fontSize:14, color:'var(--gold2)', fontWeight:900, letterSpacing:'.05em'}}>
          {title}
        </h4>
        <button onClick={()=>setKeys(prev => ({...prev, [k]: prev[k]+1}))} style={{
          background:'rgba(212,168,67,.15)',
          border:'1px solid var(--gold)',
          borderRadius:4,
          color:'#f0c850',
          fontFamily:'var(--font-sans)', fontSize:11, fontWeight:700,
          padding:'4px 12px',
          cursor:'pointer'
        }}>↻ 重擲</button>
      </div>
      <div style={{flex:1}}>
        <Variant playKey={keys[k]} />
      </div>
      <div style={{
        fontSize:11, color:'var(--fg2)', fontFamily:'var(--font-sans)',
        lineHeight:1.5, marginTop:8
      }}>{desc}</div>
    </div>
  );

  return (
    <div className="felt-bg artboard-pad">
      <div className="h-title">擲骰動畫 · DICE ROLL VARIATIONS — 點重擲試試</div>

      <div style={{
        display:'grid',
        gridTemplateColumns:'1fr 1fr',
        gap:20
      }}>
        <Section title="A · 經典旋轉" k="a" Variant={VariantClassic}
          desc="現在風格的進化版 — 真實 3D 立方體（六面紅點），緩慢減速旋轉，定格金光。穩重不誇張。" />
        <Section title="B · 翻滾彈跳" k="b" Variant={VariantTumble}
          desc="先飛起翻滾再落地彈跳兩下，落定金光。比經典版更有重量感。" />
        <Section title="C · 拋擲拋物線" k="c" Variant={VariantToss}
          desc="兩顆骰從兩側拋進場中心，拋物線軌跡 + 落地滾動 + 停下亮光。最戲劇化。" />
        <Section title="D · 骰盅搖（最擬真）" k="d" Variant={VariantBowl}
          desc="木製骰盅內骰子高速振動 → 倒出落下 → 彈跳定格。最像真實麻將開局擲骰流程。" />
      </div>

      <div style={{marginTop:18, padding:'12px 16px',
        background:'rgba(0,0,0,.25)', borderRadius:6,
        fontSize:12, color:'var(--fg2)', fontFamily:'var(--font-sans)', lineHeight:1.6}}>
        <strong style={{color:'#f0c850'}}>選哪個？</strong> A 改動最小、最穩；B 增加重量感；C 最戲劇但稍誇張；
        <strong style={{color:'#f0c850'}}> D 最擬真</strong>（接近實體麻將開局），但實作複雜度最高。建議在 Tweaks 加開關讓玩家選。
      </div>
    </div>
  );
};

window.DiceArtboard = DiceArtboard;
