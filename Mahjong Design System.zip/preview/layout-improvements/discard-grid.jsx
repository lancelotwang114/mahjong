// Tile helper used across all artboards
const Tile = ({ suit, v, size = 'sm', cls = '', style = {} }) => (
  <div className={`t ${size} ${suit} v${v} ${cls}`} style={style}></div>
);
const Back = ({ size = 'sm', style = {} }) => (
  <div className={`t ${size} back-css`} style={style}></div>
);
window.Tile = Tile;
window.Back = Back;

// === DISCARD GRID — 棄牌堆 ===
const DiscardGridArtboard = () => {
  // a realistic discard sequence
  const discards = [
    {s:'man',v:1},{s:'pin',v:5},{s:'sou',v:7},{s:'honor',v:0},
    {s:'man',v:9},{s:'pin',v:2},{s:'sou',v:3},{s:'honor',v:4},
    {s:'pin',v:8},{s:'man',v:4},{s:'sou',v:1},{s:'honor',v:6},
    {s:'man',v:6},{s:'pin',v:9},{s:'sou',v:5}
  ];
  const last = discards.length - 1;

  return (
    <div className="felt-bg artboard-pad">
      <div className="h-title">棄牌堆排列 · DISCARD PILE LAYOUT</div>

      <div className="compare">
        {/* OLD: scattered around pool */}
        <div>
          <h4>目前 <span className="badge-old">● 散落式</span></h4>
          <div style={{
            position:'relative', width:'100%', height:240,
            background: 'radial-gradient(circle at 50% 50%, rgba(0,0,0,.25), transparent 60%)',
            borderRadius: 8
          }}>
            {/* compass */}
            <div style={{
              position:'absolute', left:'50%', top:'50%',
              transform:'translate(-50%,-50%)',
              width:90, height:90, borderRadius:'50%',
              border:'1.5px solid rgba(212,168,67,.5)',
              display:'flex', alignItems:'center', justifyContent:'center',
              fontFamily:'var(--font-display)', color:'var(--gold2)', fontSize:18
            }}>東風</div>
            {/* random spread */}
            {discards.slice(0,8).map((d,i) => {
              const angle = (i / 8) * Math.PI * 2;
              const r = 90;
              const x = 50 + Math.cos(angle) * r * 0.7;
              const y = 50 + Math.sin(angle) * r * 0.6;
              return (
                <div key={i} style={{
                  position:'absolute',
                  left:`${x}%`, top:`${y}%`,
                  transform:`translate(-50%,-50%) rotate(${(i*23)%30 - 15}deg)`,
                }}>
                  <Tile suit={d.s} v={d.v} size="sm" />
                </div>
              );
            })}
          </div>
          <div className="caption">
            棄牌散落在中央 pool 區，難以一眼數出河中的牌、難以判斷對手丟過什麼花色。
          </div>
        </div>

        {/* NEW: 6-column grid in front of player */}
        <div>
          <h4>建議改進 <span className="badge-new">● 6×N 河池網格</span></h4>
          <div style={{
            position:'relative', width:'100%', height:240,
            background: 'radial-gradient(circle at 50% 50%, rgba(0,0,0,.25), transparent 60%)',
            borderRadius: 8,
            display:'flex', alignItems:'center', justifyContent:'center'
          }}>
            <div style={{
              display:'grid',
              gridTemplateColumns:'repeat(6, 32px)',
              gap:'4px',
              padding:'12px',
              background:'rgba(0,0,0,.18)',
              borderRadius:6
            }}>
              {discards.map((d,i) => (
                <div key={i} style={{
                  position:'relative',
                  ...(i === last ? {
                    outline:'2.5px solid #f0c850',
                    boxShadow:'0 0 14px rgba(212,168,67,.85)',
                    borderRadius:4,
                    transform:'scale(1.06)'
                  } : {})
                }}>
                  <Tile suit={d.s} v={d.v} size="sm" />
                </div>
              ))}
            </div>
          </div>
          <div className="caption">
            雀魂 / 天鳳的標準排法 — 每家棄牌固定 <strong>6 欄網格</strong>，最多 3 行 = 18 張。
            最後一張用金色光暈。一眼能數出河中還剩多少張該花色，方便防守判斷。
          </div>
        </div>
      </div>

      <div style={{marginTop: 24}}>
        <h4 style={{margin:'0 0 12px 0', fontFamily:'var(--font-sans)', fontSize:12, color:'var(--fg2)', fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase'}}>
          整桌效果預覽 — 三層結構：手牌 → 棄牌河 → 中央 compass
        </h4>
        <div style={{
          position:'relative', width:'100%', height:640,
          background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,.2), transparent 70%)',
          border:'1px solid rgba(212,168,67,.18)',
          borderRadius: 12,
          overflow:'hidden'
        }}>
          {/* ============ TOP — p2 (opponent)  ※ 全部正對玩家（不旋轉） ============ */}
          {/* p2 hand on outermost edge */}
          <div style={{
            position:'absolute', left:'50%', top:14,
            transform:'translateX(-50%)',
            display:'flex', gap:1
          }}>
            {Array.from({length:14}).map((_,i)=>(
              <div key={i} className="t ti back-css"></div>
            ))}
          </div>
          {/* p2 discard river — upright, faces viewer */}
          <div style={{
            position:'absolute', left:'50%', top:62,
            transform:'translateX(-50%)',
            display:'grid', gridTemplateColumns:'repeat(6, 22px)', gap:0
          }}>
            {discards.slice(0,12).map((d,i)=>(
              <Tile key={i} suit={d.s} v={d.v} size="ti" />
            ))}
          </div>

          {/* ============ LEFT — p3  ※ 上下排列、牌面正對玩家 ============ */}
          {/* p3 hand: vertical column, tiles upright */}
          <div style={{
            position:'absolute', left:14, top:'50%',
            transform:'translateY(-50%)',
            display:'flex', flexDirection:'column', gap:1
          }}>
            {Array.from({length:14}).map((_,i)=>(
              <div key={i} className="t ti back-css"></div>
            ))}
          </div>
          {/* p3 discard river: 6 rows × N cols, tiles upright */}
          <div style={{
            position:'absolute', left:46, top:'50%',
            transform:'translateY(-50%)',
            display:'grid', gridTemplateRows:'repeat(6, 28px)', gridAutoFlow:'column', gap:0
          }}>
            {discards.slice(0,9).map((d,i)=>(
              <Tile key={i} suit={d.s} v={(d.v+i)%9 || 1} size="ti" />
            ))}
          </div>

          {/* ============ RIGHT — p1  ※ 上下排列、牌面正對玩家 ============ */}
          <div style={{
            position:'absolute', right:14, top:'50%',
            transform:'translateY(-50%)',
            display:'flex', flexDirection:'column', gap:1
          }}>
            {Array.from({length:14}).map((_,i)=>(
              <div key={i} className="t ti back-css"></div>
            ))}
          </div>
          <div style={{
            position:'absolute', right:46, top:'50%',
            transform:'translateY(-50%)',
            display:'grid', gridTemplateRows:'repeat(6, 28px)', gridAutoFlow:'column', gap:0
          }}>
            {discards.slice(0,11).map((d,i)=>(
              <Tile key={i} suit={d.s} v={(d.v+i+2)%9 || 2} size="ti" />
            ))}
          </div>

          {/* ============ BOTTOM — self (p0) ============ */}
          <div style={{
            position:'absolute', left:'50%', bottom:14,
            transform:'translateX(-50%)',
            display:'flex', gap:0
          }}>
            {Array.from({length:16}).map((_,i)=>(
              <Tile key={i} suit={['man','pin','sou'][i%3]} v={(i%9)+1} size="sm" />
            ))}
          </div>
          <div style={{
            position:'absolute', left:'50%', bottom:78,
            transform:'translateX(-50%)',
            display:'grid', gridTemplateColumns:'repeat(6, 22px)', gap:0
          }}>
            {discards.map((d,i)=>(
              <div key={i} style={{
                ...(i === last ? {
                  outline:'2.5px solid #f0c850',
                  boxShadow:'0 0 14px rgba(212,168,67,.85)',
                  borderRadius:4,
                } : {})
              }}>
                <Tile suit={d.s} v={d.v} size="ti" />
              </div>
            ))}
          </div>

          {/* ============ CENTER COMPASS (drawn last so it's on top of nothing) ============ */}
          <div style={{
            position:'absolute', left:'50%', top:'50%',
            transform:'translate(-50%,-50%)',
            width:130, height:130, borderRadius:'50%',
            border:'2px solid rgba(212,168,67,.6)',
            background:'radial-gradient(circle, rgba(0,0,0,.5), rgba(0,0,0,.85))',
            display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
            fontFamily:'var(--font-display)', color:'var(--gold2)',
            boxShadow:'inset 0 0 12px rgba(0,0,0,.6), 0 0 18px rgba(0,0,0,.5)'
          }}>
            <div style={{fontSize:24, lineHeight:1}}>東風</div>
            <div style={{fontSize:11, color:'var(--fg2)', fontFamily:'var(--font-sans)', marginTop:4}}>第 1 局 · 1本場</div>
            <div style={{
              fontSize:22, color:'var(--gold2)',
              fontFamily:'var(--font-serif)', fontWeight:900,
              marginTop:6, fontVariantNumeric:'tabular-nums', lineHeight:1
            }}>56</div>
            <div style={{fontSize:9, color:'var(--fg2)', fontFamily:'var(--font-sans)', marginTop:2}}>剩餘張數</div>
          </div>
        </div>
        <div className="caption" style={{marginTop:10}}>
          三層同心結構，互不重疊：<strong>外層手牌</strong> → <strong>中層棄牌河（6×N 網格）</strong> → <strong>內層 compass（場況面板）</strong>。
          每家棄牌都在自己手牌正前方，中央只顯示場風 / 局數 / 本場 / 剩餘牌數。
        </div>
      </div>
    </div>
  );
};

window.DiscardGridArtboard = DiscardGridArtboard;
