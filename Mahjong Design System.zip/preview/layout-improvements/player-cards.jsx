// === PLAYER CARDS — 玩家卡片 ===

// Three variations: minimal (closer to current), standard (雀魂-like), rich (Riichi City-like)

const PlayerCardMinimal = ({ name, wind, dealer, chips, isTurn, avatar, rank }) => (
  <div style={{
    display:'flex', alignItems:'center', gap:10,
    padding:'8px 12px',
    background: isTurn ? 'rgba(212,168,67,.16)' : 'rgba(0,0,0,.35)',
    border: isTurn ? '1.5px solid #f0c850' : '1px solid rgba(212,168,67,.3)',
    borderRadius: 8,
    minWidth: 200,
    boxShadow: isTurn ? '0 0 14px rgba(212,168,67,.5)' : 'none'
  }}>
    <div style={{
      width:34, height:34, borderRadius:'50%',
      background:'rgba(0,0,0,.5)',
      border:'1.5px solid var(--gold)',
      display:'flex', alignItems:'center', justifyContent:'center',
      fontSize:18
    }}>{avatar}</div>
    <div style={{flex:1, minWidth:0}}>
      <div style={{display:'flex', alignItems:'center', gap:6}}>
        <span style={{
          fontFamily:'var(--font-serif)', fontWeight:700, fontSize:13,
          color: dealer ? '#f0c850' : 'var(--fg1)'
        }}>{name}</span>
        {dealer && <span style={{
          fontSize:9, fontFamily:'var(--font-serif)', fontWeight:900,
          color:'#f0c850', border:'1px solid #f0c850',
          padding:'0 4px', borderRadius:3, lineHeight:'14px'
        }}>莊</span>}
      </div>
      <div style={{fontSize:11, color:'var(--fg2)', fontFamily:'var(--font-sans)'}}>
        {wind} · ${chips.toLocaleString()}
      </div>
    </div>
  </div>
);

const PlayerCardStandard = ({ name, wind, dealer, chips, isTurn, avatar, rank, tenpai }) => (
  <div style={{
    display:'flex', flexDirection:'column', gap:6,
    padding: '10px 12px',
    background: isTurn
      ? 'linear-gradient(135deg, rgba(212,168,67,.22), rgba(212,168,67,.08))'
      : 'linear-gradient(135deg, rgba(0,0,0,.5), rgba(0,0,0,.3))',
    border: isTurn ? '2px solid #f0c850' : '1px solid rgba(212,168,67,.35)',
    borderRadius: 10,
    width: 180,
    position: 'relative',
    boxShadow: isTurn ? '0 0 18px rgba(212,168,67,.55)' : '0 2px 6px rgba(0,0,0,.4)'
  }}>
    {/* turn timer ring */}
    {isTurn && (
      <div style={{
        position:'absolute', top:-6, right:-6,
        width:18, height:18, borderRadius:'50%',
        border:'2px solid #f0c850',
        background:'#0a3d2e',
        display:'flex', alignItems:'center', justifyContent:'center',
        fontSize:10, color:'#f0c850', fontFamily:'var(--font-serif)', fontWeight:900
      }}>15</div>
    )}

    <div style={{display:'flex', alignItems:'center', gap:10}}>
      <div style={{
        width:42, height:42, borderRadius:'50%',
        background:'radial-gradient(circle at 30% 30%, rgba(212,168,67,.3), rgba(0,0,0,.6))',
        border:'2px solid var(--gold)',
        display:'flex', alignItems:'center', justifyContent:'center',
        fontSize:22, position:'relative', flexShrink:0
      }}>
        {avatar}
        {/* wind tag overlap */}
        <div style={{
          position:'absolute', bottom:-4, right:-4,
          width:18, height:18, borderRadius:'50%',
          background: dealer ? '#f0c850' : '#0a3d2e',
          color: dealer ? '#0a3d2e' : '#f0c850',
          border: '1.5px solid #d4a843',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:11, fontFamily:'var(--font-serif)', fontWeight:900,
          lineHeight: 1
        }}>{wind}</div>
      </div>
      <div style={{flex:1, minWidth:0}}>
        <div style={{
          fontFamily:'var(--font-serif)', fontWeight:700, fontSize:14,
          color: 'var(--fg1)',
          whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'
        }}>{name}</div>
        <div style={{fontSize:10, color:'var(--gold3)', fontFamily:'var(--font-sans)', letterSpacing:'.05em'}}>
          {rank}
        </div>
      </div>
    </div>
    {/* chips bar */}
    <div style={{
      display:'flex', alignItems:'center', justifyContent:'space-between',
      padding:'4px 8px',
      background:'rgba(0,0,0,.4)',
      borderRadius: 4,
      borderLeft: tenpai ? '2px solid #5fb878' : '2px solid transparent'
    }}>
      <span style={{fontSize:10, color:'var(--fg2)', fontFamily:'var(--font-sans)'}}>
        {tenpai ? '聽牌' : '籌碼'}
      </span>
      <span style={{
        fontFamily:'var(--font-serif)', fontWeight:900, fontSize:14,
        color: tenpai ? '#5fb878' : '#f0c850',
        fontVariantNumeric:'tabular-nums'
      }}>
        ${chips.toLocaleString()}
      </span>
    </div>
  </div>
);

const PlayerCardRich = ({ name, wind, dealer, chips, isTurn, avatar, rank, tenpai, lastDelta }) => (
  <div style={{
    display:'flex', flexDirection:'column',
    background: isTurn
      ? 'linear-gradient(135deg, rgba(212,168,67,.28), rgba(48,30,8,.6))'
      : 'linear-gradient(135deg, rgba(20,40,30,.8), rgba(8,20,15,.9))',
    border: isTurn ? '2px solid #f0c850' : '1px solid rgba(212,168,67,.3)',
    borderRadius: 12,
    width: 200,
    overflow:'hidden',
    position:'relative',
    boxShadow: isTurn ? '0 0 20px rgba(212,168,67,.6)' : '0 4px 12px rgba(0,0,0,.5)'
  }}>
    {/* header: avatar + name + rank */}
    <div style={{
      display:'flex', alignItems:'center', gap:10,
      padding:'10px 12px 8px',
      background: 'linear-gradient(180deg, rgba(0,0,0,.3), transparent)'
    }}>
      <div style={{position:'relative'}}>
        <div style={{
          width:48, height:48, borderRadius:'50%',
          background:'radial-gradient(circle at 30% 30%, rgba(212,168,67,.3), rgba(0,0,0,.7))',
          border:'2px solid var(--gold)',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:26
        }}>{avatar}</div>
        {/* turn ring */}
        {isTurn && (
          <svg style={{position:'absolute', inset:-3, width:54, height:54}} viewBox="0 0 54 54">
            <circle cx="27" cy="27" r="25" fill="none" stroke="#f0c850" strokeWidth="2"
              strokeDasharray="157" strokeDashoffset="40"
              transform="rotate(-90 27 27)"
              style={{filter:'drop-shadow(0 0 4px rgba(240,200,80,.8))'}} />
          </svg>
        )}
      </div>
      <div style={{flex:1, minWidth:0}}>
        <div style={{
          display:'flex', alignItems:'center', gap:5, marginBottom:2
        }}>
          <span style={{
            fontFamily:'var(--font-serif)', fontWeight:700, fontSize:14,
            color: 'var(--fg1)',
            whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'
          }}>{name}</span>
          {dealer && (
            <span style={{
              fontSize:9, fontFamily:'var(--font-serif)', fontWeight:900,
              color:'#0a3d2e', background:'#f0c850',
              padding:'1px 5px', borderRadius:3, lineHeight:1
            }}>莊家</span>
          )}
        </div>
        <div style={{display:'flex', alignItems:'center', gap:6}}>
          <span style={{
            fontSize:10, fontFamily:'var(--font-serif)', fontWeight:900,
            color: dealer ? '#f0c850' : 'var(--fg2)',
            border:'1px solid currentColor',
            padding:'0 5px', borderRadius:'999px',
            lineHeight:'14px'
          }}>{wind}風</span>
          <span style={{fontSize:10, color:'var(--gold3)', fontFamily:'var(--font-sans)'}}>
            {rank}
          </span>
        </div>
      </div>
    </div>

    {/* chips + delta */}
    <div style={{
      display:'flex', alignItems:'baseline', gap:8,
      padding:'4px 12px 10px',
      borderTop: '1px solid rgba(212,168,67,.15)'
    }}>
      <span style={{fontSize:9, color:'var(--fg2)', fontFamily:'var(--font-sans)', letterSpacing:'.05em'}}>$</span>
      <span style={{
        fontFamily:'var(--font-serif)', fontWeight:900, fontSize:18,
        color: '#f0c850',
        fontVariantNumeric:'tabular-nums', lineHeight:1
      }}>{chips.toLocaleString()}</span>
      {lastDelta !== 0 && (
        <span style={{
          fontSize:11, fontFamily:'var(--font-sans)', fontWeight:700,
          color: lastDelta > 0 ? '#5fb878' : '#e85a4f',
          marginLeft:'auto'
        }}>{lastDelta > 0 ? '+' : ''}{lastDelta}</span>
      )}
    </div>

    {/* status footer */}
    {tenpai && (
      <div style={{
        background: 'linear-gradient(90deg, rgba(95,184,120,.3), rgba(95,184,120,.1))',
        borderTop: '1px solid rgba(95,184,120,.4)',
        padding: '4px 12px',
        fontSize: 10,
        fontFamily: 'var(--font-serif)', fontWeight:700,
        color: '#5fb878',
        letterSpacing: '.08em'
      }}>● 聽牌</div>
    )}
  </div>
);

const PlayerCardsArtboard = () => (
  <div className="felt-bg artboard-pad">
    <div className="h-title">玩家卡片 · PLAYER CARD VARIATIONS</div>

    <div style={{display:'flex', flexDirection:'column', gap:24}}>

      {/* Variation A — minimal */}
      <div>
        <h4 style={{margin:'0 0 10px 0', fontFamily:'var(--font-sans)', fontSize:12, color:'var(--fg2)', fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase'}}>
          A · 簡約版（接近目前風格 + 補上頭像）
        </h4>
        <div style={{display:'flex', gap:12, flexWrap:'wrap'}}>
          <PlayerCardMinimal name="玩家"   wind="東" dealer={true}  chips={5000} isTurn={true}  avatar="🎴" rank="—" />
          <PlayerCardMinimal name="小南"   wind="南" dealer={false} chips={4800} isTurn={false} avatar="🐯" rank="—" />
          <PlayerCardMinimal name="小西"   wind="西" dealer={false} chips={5300} isTurn={false} avatar="🐉" rank="—" />
          <PlayerCardMinimal name="小北"   wind="北" dealer={false} chips={4900} isTurn={false} avatar="🦢" rank="—" />
        </div>
        <div className="caption">
          補上頭像 + 風位 + 莊家標記，但保留現在的單行緊湊感。最低改動量。
        </div>
      </div>

      {/* Variation B — standard */}
      <div>
        <h4 style={{margin:'0 0 10px 0', fontFamily:'var(--font-sans)', fontSize:12, color:'var(--fg2)', fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase'}}>
          B · 標準版（雀魂風格 · 含倒數計時 + 段位）
        </h4>
        <div style={{display:'flex', gap:14, flexWrap:'wrap'}}>
          <PlayerCardStandard name="玩家"   wind="東" dealer={true}  chips={5000} isTurn={true}  avatar="🎴" rank="雀士 ★" tenpai={false} />
          <PlayerCardStandard name="小南"   wind="南" dealer={false} chips={4800} isTurn={false} avatar="🐯" rank="雀傑 ★★" tenpai={false} />
          <PlayerCardStandard name="小西"   wind="西" dealer={false} chips={5300} isTurn={false} avatar="🐉" rank="雀豪 ★★★" tenpai={true} />
          <PlayerCardStandard name="小北"   wind="北" dealer={false} chips={4900} isTurn={false} avatar="🦢" rank="雀士 ★" tenpai={false} />
        </div>
        <div className="caption">
          頭像疊上風位徽章、出牌倒數圈、段位顯示、聽牌綠邊條。資訊密度適中、可讀性最佳。
        </div>
      </div>

      {/* Variation C — rich */}
      <div>
        <h4 style={{margin:'0 0 10px 0', fontFamily:'var(--font-sans)', fontSize:12, color:'var(--fg2)', fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase'}}>
          C · 完整版（Riichi City 風格 · 含本局損益 + 完整環形計時）
        </h4>
        <div style={{display:'flex', gap:14, flexWrap:'wrap'}}>
          <PlayerCardRich name="玩家"   wind="東" dealer={true}  chips={5000} isTurn={true}  avatar="🎴" rank="雀士 ★" tenpai={false} lastDelta={0} />
          <PlayerCardRich name="小南"   wind="南" dealer={false} chips={4800} isTurn={false} avatar="🐯" rank="雀傑 ★★" tenpai={false} lastDelta={-200} />
          <PlayerCardRich name="小西"   wind="西" dealer={false} chips={5300} isTurn={false} avatar="🐉" rank="雀豪 ★★★" tenpai={true}  lastDelta={+300} />
          <PlayerCardRich name="小北"   wind="北" dealer={false} chips={4900} isTurn={false} avatar="🦢" rank="雀士 ★" tenpai={false} lastDelta={-100} />
        </div>
        <div className="caption">
          兩段式佈局（頭像區 + 籌碼區 + 狀態欄），SVG 環形倒數，本局損益綠/紅顯示。最有「在線麻將大廳」氣場。
        </div>
      </div>

    </div>
  </div>
);

window.PlayerCardsArtboard = PlayerCardsArtboard;
