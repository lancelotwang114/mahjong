// === HAND with DRAWN tile separation + tenpai preview ===

const HandDrawnArtboard = () => {
  // 16 tiles in hand + 1 just-drawn
  const hand = [
    {s:'man',v:1},{s:'man',v:2},{s:'man',v:3},
    {s:'pin',v:2},{s:'pin',v:3},{s:'pin',v:4},
    {s:'sou',v:5},{s:'sou',v:6},{s:'sou',v:7},
    {s:'sou',v:7},{s:'sou',v:7},
    {s:'pin',v:8},{s:'pin',v:8},
    {s:'man',v:9},{s:'man',v:9},{s:'man',v:9},
  ];
  const drawn = {s:'pin', v:5};

  return (
    <div className="felt-bg artboard-pad">
      <div className="h-title">手牌排列 · HAND LAYOUT WITH DRAWN TILE</div>

      <div style={{display:'flex', flexDirection:'column', gap:20}}>

        {/* OLD: all glued together */}
        <div style={{
          background: 'rgba(0,0,0,.18)',
          border: '1px solid rgba(212,168,67,.18)',
          borderRadius: 8, padding: 18
        }}>
          <h4 style={{margin:'0 0 12px 0', fontFamily:'var(--font-sans)', fontSize:12, color:'var(--fg2)', fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase'}}>
            目前 <span style={{color:'#e85a4f'}}>● 全部黏一起</span>
          </h4>
          <div style={{
            display:'flex', gap:0,
            background:'rgba(0,0,0,.3)',
            padding:'10px',
            borderRadius:6,
            justifyContent:'center'
          }}>
            {hand.map((t,i)=>(<Tile key={i} suit={t.s} v={t.v} size="sm" />))}
            <Tile suit={drawn.s} v={drawn.v} size="sm" />
          </div>
          <div className="caption" style={{marginTop:10}}>
            16 + 1 張全部貼在一起，看不出哪張是剛摸的。手感跟現代麻將遊戲差距明顯。
          </div>
        </div>

        {/* NEW: separated drawn tile */}
        <div style={{
          background: 'rgba(0,0,0,.18)',
          border: '1px solid rgba(212,168,67,.18)',
          borderRadius: 8, padding: 18
        }}>
          <h4 style={{margin:'0 0 12px 0', fontFamily:'var(--font-sans)', fontSize:12, color:'var(--fg2)', fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase'}}>
            建議改進 <span style={{color:'#5fb878'}}>● 牌縫 + 摸牌獨立</span>
          </h4>
          <div style={{
            display:'flex',
            background:'rgba(0,0,0,.3)',
            padding:'10px',
            borderRadius:6,
            justifyContent:'center',
            alignItems:'flex-end'
          }}>
            <div style={{display:'flex', gap:'3px'}}>
              {hand.map((t,i)=>(<Tile key={i} suit={t.s} v={t.v} size="sm" />))}
            </div>
            <div style={{width:16}}></div>
            <div style={{position:'relative'}}>
              <Tile suit={drawn.s} v={drawn.v} size="sm"
                style={{
                  outline:'1.5px solid rgba(212,168,67,.5)',
                  borderRadius:4
                }} />
              <div style={{
                position:'absolute', top:-16, left:'50%',
                transform:'translateX(-50%)',
                fontSize:9, color:'#f0c850',
                fontFamily:'var(--font-serif)', fontWeight:700,
                whiteSpace:'nowrap'
              }}>剛摸</div>
            </div>
          </div>
          <div className="caption" style={{marginTop:10}}>
            手牌之間 <code className="code">gap: 3px</code>，剛摸的牌跟手牌間隔 <code className="code">16px</code> 並有金邊。
            玩家一眼能看出「這張是新進的」。
          </div>
        </div>

        {/* HOVER: tenpai preview */}
        <div style={{
          background: 'rgba(0,0,0,.18)',
          border: '1px solid rgba(212,168,67,.18)',
          borderRadius: 8, padding: 18
        }}>
          <h4 style={{margin:'0 0 12px 0', fontFamily:'var(--font-sans)', fontSize:12, color:'var(--fg2)', fontWeight:700, letterSpacing:'.08em', textTransform:'uppercase'}}>
            進階 <span style={{color:'#5fb878'}}>● Hover 顯示「打出後聽 N 張」</span>
          </h4>
          <div style={{
            display:'flex',
            background:'rgba(0,0,0,.3)',
            padding:'10px 10px 24px',
            borderRadius:6,
            justifyContent:'center',
            alignItems:'flex-end',
            position:'relative'
          }}>
            <div style={{display:'flex', gap:'3px', position:'relative'}}>
              {hand.map((t,i)=>(
                <div key={i} style={{
                  position:'relative',
                  ...(i === 11 ? {
                    transform:'translateY(-12px)',
                  } : { opacity: 0.55 })
                }}>
                  <Tile suit={t.s} v={t.v} size="sm"
                    style={i === 11 ? {
                      outline: '2.5px solid #f0c850',
                      boxShadow: '0 0 14px rgba(212,168,67,.85)',
                      borderRadius: 4
                    } : {}} />
                  {/* tooltip on the hovered tile */}
                  {i === 11 && (
                    <div style={{
                      position:'absolute', bottom: 'calc(100% + 18px)', left:'50%',
                      transform:'translateX(-50%)',
                      background:'rgba(10,30,22,.96)',
                      border:'1.5px solid #f0c850',
                      borderRadius:6,
                      padding:'8px 12px',
                      whiteSpace:'nowrap',
                      boxShadow:'0 4px 14px rgba(0,0,0,.6)',
                      zIndex: 5
                    }}>
                      <div style={{
                        fontSize:11, color:'#f0c850',
                        fontFamily:'var(--font-serif)', fontWeight:700,
                        marginBottom:4
                      }}>打出 8筒 後 · 聽 3 張</div>
                      <div style={{display:'flex', gap:3}}>
                        <div className="t ti pin v1"></div>
                        <div className="t ti pin v4"></div>
                        <div className="t ti pin v7"></div>
                      </div>
                      {/* arrow */}
                      <div style={{
                        position:'absolute', bottom:-8, left:'50%',
                        transform:'translateX(-50%)',
                        width:0, height:0,
                        borderLeft:'8px solid transparent',
                        borderRight:'8px solid transparent',
                        borderTop:'8px solid #f0c850'
                      }}></div>
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div style={{width:16}}></div>
            <Tile suit={drawn.s} v={drawn.v} size="sm" style={{ opacity: 0.55 }} />
          </div>
          <div className="caption" style={{marginTop:10}}>
            滑鼠 hover 任一手牌 → 該牌浮起 + 金光，其他手牌變半透明，上方氣泡顯示「打出此牌後聽 N 張」。
            點一次 = 預覽，點兩次 = 確認出牌。
          </div>
        </div>

      </div>
    </div>
  );
};

window.HandDrawnArtboard = HandDrawnArtboard;
