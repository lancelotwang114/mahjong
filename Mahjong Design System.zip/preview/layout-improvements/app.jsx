// === APP — design canvas with all four artboards ===

const App = () => {
  return (
    <DesignCanvas>
      <DCSection id="discard-grid" title="① 棄牌堆網格化">
        <DCArtboard id="discard-compare" label="散落 vs 6×N 網格 + 整桌效果" width={1080} height={1120}>
          <DiscardGridArtboard />
        </DCArtboard>
      </DCSection>

      <DCSection id="player-cards" title="② 玩家卡片（A / B / C 三版本）">
        <DCArtboard id="player-cards-compare" label="簡約 / 標準 / 完整" width={1080} height={920}>
          <PlayerCardsArtboard />
        </DCArtboard>
      </DCSection>

      <DCSection id="hand-drawn" title="③ 手牌剛摸的牌獨立 + 出牌預覽">
        <DCArtboard id="hand-compare" label="目前 vs 牌縫 + 摸牌獨立 vs Hover 預覽" width={1080} height={960}>
          <HandDrawnArtboard />
        </DCArtboard>
      </DCSection>

      <DCSection id="dice" title="④ 擲骰動畫（A / B / C / D 四版本，點重擲試試）">
        <DCArtboard id="dice-compare" label="經典旋轉 / 翻滾彈跳 / 拋擲 / 骰盅搖" width={1080} height={620}>
          <DiceArtboard />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
