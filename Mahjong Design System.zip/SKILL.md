---
name: mahjong-design
description: Use this skill to generate well-branded interfaces and assets for the 台灣麻將 (Taiwan Mahjong) solo game, either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping. The brand is dim, warm, casino-lit — deep emerald felt, wood frames, gold accents, ivory tile faces with red/blue/green inks, and traditional Chinese Ma Shan Zheng script for hero moments.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. Use `colors_and_type.css` as the foundation — it provides the felt/gold/ivory/ink palette and Ma Shan Zheng / Noto Serif TC / Noto Sans TC type stack. The `ui_kits/solo-game/` folder has interactive component recreations for the lobby, table, tile, compass, badges, and overlays.

If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand. Pay attention to the **iconography constraint** (CJK glyphs and the tile sprite system — never invent SVG icons or use icon libraries) and the **content tone** (terse Mandarin Traditional, no "you"/"I", game-vocabulary canonical, emoji used surgically on dedicated controls).

If the user invokes this skill without any other guidance, ask them what they want to build or design (a new game screen? a marketing landing for the game? a print poster?), ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.
